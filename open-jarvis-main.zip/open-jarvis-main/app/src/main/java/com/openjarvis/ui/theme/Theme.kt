package com.openjarvis.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object VoidColor {
    val Void950 = Color(0xFF05050A)
    val Void900 = Color(0xFF0A0A12)
    val Void800 = Color(0xFF12121D)
    val Void700 = Color(0xFF1B1B2A)
    val Void600 = Color(0xFF26263A)

    val Violet = Color(0xFF8B5CF6)
    val VioletDim = Color(0xFF5B3CB0)
    val Cyan = Color(0xFF22D3EE)
    val Green = Color(0xFF34D399)
    val Amber = Color(0xFFFBBF24)
    val Red = Color(0xFFF87171)

    val TextPrimary = Color(0xFFF2F2F7)
    val TextSecondary = Color(0xFFA1A1B5)
    val TextDisabled = Color(0xFF5E5E73)

    val BorderSubtle = Color(0xFF2A2A3D)
    val BorderGlow = Color(0xFF6D4AD6)
}

private val VoidColorScheme = darkColorScheme(
    primary = VoidColor.Violet,
    secondary = VoidColor.Cyan,
    background = VoidColor.Void950,
    surface = VoidColor.Void900,
    surfaceVariant = VoidColor.Void800,
    error = VoidColor.Red,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = VoidColor.TextPrimary,
    onSurface = VoidColor.TextPrimary,
    onSurfaceVariant = VoidColor.TextSecondary,
    onError = Color.Black
)

@Composable
fun OpenJarvisTheme(
    @Suppress("UNUSED_PARAMETER") darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(colorScheme = VoidColorScheme, content = content)
}
